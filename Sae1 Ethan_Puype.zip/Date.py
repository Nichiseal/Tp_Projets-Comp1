# Implémentation des dates et calendriers
# Implémentation des tests (voir main en fin de fichier)

from typing import Dict, List, Tuple, NoReturn
from dataclasses import dataclass
import numpy as np



# =============================================================================
def est_bissextile(annee: int) -> bool :
    """
    retourne vrai si l'année est bissextile

    >>> est_bissextile(2020)
    True
    >>> est_bissextile(2021)
    False
    >>> est_bissextile(2022)
    False
    >>> est_bissextile(1900)
    False
    >>> est_bissextile(2000)
    True
    """ 
    if annee%4==0 and annee%100!=0 or annee%400==0:     #vérifie si l'année rentrée est bissextile en la divisant par 4 et 100 ou par 400
        return True
    else:
        return False


    
# =============================================================================
def cree_date(j: int, m: int, a: int) -> Dict :
    """
    Crée une date à partir des entiers la décrivant.
    Si l'un des paramètres n'est pas un entier, la fonction retournera None

    >>> cree_date(15,12,2020)
    {'jour': 15, 'mois': 12, 'annee': 2020}
    >>> cree_date(1.5,12,2020)

    """
    jour_mois_annee = {"jour":j,"mois":m,"annee":a}         #Attribue les valeurs des variables aux clés correspondantes du dictionnaires.


    if j%1!=0 or m%1!=0 or a%1!=0: #Verifie si les valeurs entréessont des integer
        return None
    else:
        return jour_mois_annee


    
# =============================================================================
def copie_date(date: Dict) -> Dict :
    """
    copie la date passée en paramètre
    
    >>> copie_date()

    """
    date_copie=date["jour","mois","annee"]  #ne fonctionne pas


    
# =============================================================================
def compare(d1: Dict, d2: Dict) -> int :
    """
    Permet de classer deux dates.
    Retourne
    -1 si la date d1 < d2
    +1 si la date d1 > d2
    0 si les dates sont identiques
    on considère que les dates sont croissantes 
    dans l'ordre chronologique

    >>> date1 = cree_date(25,12,2021)
    >>> date2 = cree_date(31,12,2021)
    >>> compare(date1,date2)
    -1
    >>> compare(date2,date1)
    1
    >>> compare(date1,date1)
    0
    """
    if d1['jour']+d1['mois']+d1['annee']<d2['jour']+d2['mois']+d2['annee']:
        return -1
    elif d1['jour']+d1['mois']+d1['annee']>d2['jour']+d2['mois']+d2['annee']:       #Fais l'addition des valeurs rentrés pour les comparer
        return 1
    elif d1['jour']+d1['mois']+d1['annee']==d2['jour']+d2['mois']+d2['annee']:
        return 0
    


# =============================================================================
def valide_simple(d: Dict) -> bool :
    """   
    retourne vrai si la date est valide.
    on supposera que la date est valide si :
    - si le premier (le jour) est un entier compris entre 1 et 31
    - si le second (le mois) est un entier compris entre 1 et 12

    >>> date = cree_date(1, 2, 0)
    >>> valide_simple(date)
    True
    >>> date = cree_date(1.5, 5, 6)
    >>> valide_simple(date)
    False
    >>> date = cree_date(0, 5, 6)
    >>> valide_simple(date)
    False
    >>> date = cree_date(20, 8, 2021)
    >>> valide_simple(date)
    True
    """
    if d!= None:                            
         if d['jour']<1 or d['jour']>31:        #Vérifie si le jour rentré respecte les conditions
             if d['mois']<1 or d['mois']>12:        #Vérifie si le mois rentré respecte les conditions
                 return False                   #Retourne faux si mois invalide       
             else:
                 return False                   #Retourne faux si jour invalide
         else:
             return True                        #Retourne vrai si la date est valide 
    else:
     return False                               #Retourne faux si une valeur rentré est décimale
    
    

# =============================================================================
def valide_complet(d: Dict) -> bool :
    """ 
    retourne vrai si la date est valide.
    on supposera que la date est valide si :
    - la validation simple est vraie
    - si la date représente une date réelle 

    >>> date = cree_date(15, 1, 2022)
    >>> valide_complet(date)
    True
    >>> date = cree_date(32, 1, 2022)
    >>> valide_complet(date)
    False
    >>> date = cree_date(-1, 1, 2022)
    >>> valide_complet(date)
    False
    >>> date = cree_date(31, 6, 2022)
    >>> valide_complet(date)
    False
    >>> date = cree_date(29, 2, 2020)
    >>> valide_complet(date)
    True
    >>> date = cree_date(29, 2, 2022)
    >>> valide_complet(date)
    False
    """
    if d['mois']==2:
        if est_bissextile(d["annee"])==False and d["jour"]>28:      #Vérifie si l'année est bissextile pour ajuster le nombres de jours max du mois
            return False
        elif d["jour"]>29:
            return False
        else:
            return True
    elif d["mois"]==4 and d["jour"]>30:         #Cas par cas le nb de jours a été réglé pour les mois de 30 joours
        return False
    elif d["mois"]==6 and d["jour"]>30:
        return False
    elif d["mois"]==9 and d["jour"]>30:
        return False
    elif d["mois"]==11 and d["jour"]>30:
        return False
    else:
        return valide_simple(d)     #Une fois tout les cas examinés la fonction vérifie si la date est valide malgré qu'elle ne fasse pas partie des cas
    


# =============================================================================
def ajoute_calendrier(calendrier: List, date: Dict, description: str ) -> NoReturn :
    """
    ajoute un élément à la liste du calendrier.
    """
    valide_complet(date)

    if valide_complet(date)==True:
        calendrier.extend([date,description]) #la fonction va vérifier la date avant de l'ajouter au calendrier
    else:
        print("Date Invalide")

    
# =============================================================================
def affiche_calendrier(calendrier: List) -> NoReturn :
    """
    affiche le calendrier sous forme de liste.
    """
    for i in range(0,len(calendrier),2):
     affiche_date=('Le' + ' ' + str(calendrier[i]['jour']) + '/' + str(calendrier[i].get("mois")) + '/' + str(calendrier[i].get("annee")) + ' '+ ':' + ' ' + calendrier[i+1]) #ceci va prendre en compte tout les valeurs affichés dans ajoute_calendrier
     print(affiche_date)


# =============================================================================    
if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)